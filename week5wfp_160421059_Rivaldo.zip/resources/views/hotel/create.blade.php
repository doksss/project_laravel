Kembali ke halaman index Hotel
<a href="{{ route ('hotels.index') }}">Silahkan Kesini</a>