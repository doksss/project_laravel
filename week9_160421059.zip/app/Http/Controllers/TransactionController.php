<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Product;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $transactions = Transaction::all(); //pake Eloquent ORM
        // dd($transactions);
        return view('transaction.index', ['data' => $transactions]); //ke folder index.blade.php dan mengirim data dengan key 'data' valuenya hotels
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $customer = Customer::all();
        $product = Product::all();
        $user = User::all();
        return view('transaction.formcreate',['customer'=>$customer,'product'=>$product,'user'=>$user]);
        
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = new Transaction();
        $data->customer_id = $request->get('customer_id');//ambil name dari textfieldnya
        $data->user_id = $request->get('user_id');//ambil name dari textfieldnya
        $data->save();

        $idTransactionNew = $data->id; //mendapatkan id transaksi yg baru di insert
        $product_id = $request->get('product_id');
        $quantity = $request->get('quantity');
        $subtotal = $request->get('subtotal');
        DB::insert('insert into product_transaction(product_id,transaction_id,quantity,subtotal) values (?,?,?,?)',
        [$product_id,$idTransactionNew,$quantity,$subtotal]);

        //confirmation
        return redirect()->route('transaction.index')->with('status','Hooray ! your data is successfully recorded!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Transaction $transaction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Transaction $transaction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Transaction $transaction)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Transaction $transaction)
    {
        //
    }
}
