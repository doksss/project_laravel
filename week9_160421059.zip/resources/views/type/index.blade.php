@extends('layout.conquer')
@section('content')

@if(@session('status'))
<div class="alert alert-success">{{session('status')}}</div>
@endif

<a href="{{route('type.create')}}" class="btn btn-success">+ New Type</a>
<table class="table">
    <thead>
        <tr>
            <th>Nama Type</th>
            <th>Description</th>
            <th>Date Created</th>
            <th>Date Update</th>
        </tr>
    </thead>
    <tbody>
        @foreach($data as $d)
        <tr>
            <td>{{$d->name}}</td>
            <td>{{$d->description}}</td>
            <td>{{$d->created_at}}</td>
            <td>{{$d->updated_at}}</td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection