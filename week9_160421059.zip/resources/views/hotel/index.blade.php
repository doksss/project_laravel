<!-- Extends ini file blade php mau ditempel ke mana -->
@extends('layout.conquer')
@section('content')
Halaman Index Hotel
<br>

<!-- BUTTON MUNCULKAN MODAL -->
<a class="btn btn-warning" data-toggle="modal" href="#disclaimer">Disclaimer!</a>
<!-- END BUTTON MUNCULKAN MODAL -->

<!-- MODAL -->
<!-- yg penting itu class modal fade dan id(ikutin button) -->
<div class="modal fade" id="disclaimer" tabindex="-1" role="basic" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title">DISCLAIMER</h4>
      </div>
      <div class="modal-body">
        Pictures shown are for illustration purpose only. Actual product may vary due to product enhancement.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- END MODAL -->

<!-- <ul>
  @foreach($data as $d)
  <li>
    {{$d->name}}
  </li>
  @endforeach
</ul> -->

<div class="container">
  <h2>Halaman Index Hotel</h2>
  <p>Table Halaman Hotel Rivaldo(160421059)</p>
  <table class="table">
    <thead>
      <tr>
        <th>Nama Hotel</th>
        <th>Alamat Hotel</th>
        <th>Kota Hotel</th>
        <th>Created At</th>
        <th>Update At</th>
        <th>Picture</th>
      </tr>
    </thead>
    <tbody>
      @foreach($data as $d)
      <tr>
        <td>{{$d->name}}</td>
        <td>{{$d->address}}</td>
        <td>{{$d->city}}</td>
        <td>{{$d->created_at}}</td>
        <td>{{$d->update_at}}</td>
        <td>
          <a class="btn btn-info" href="#detail_{{$d->id}}" data-toggle="modal">{{ $d->name }}</a>

          <div class="modal fade" id="detail_{{$d->id}}" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">{{$d->name}}</h4>
                </div>
                <div class="modal-body">
                  <img src="{{ asset($d->image)}}" height='200px' />
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        </td>

      </tr>
      @endforeach
    </tbody>
  </table>
  Kalo mau buat baru <a href="{{ route ('hotels.create') }}">Silahkan Kesini</a>
</div>
@endsection

<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <title>Page Hotels</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Halaman Index Hotel</h2>
  <p>Table Halaman Hotel Rivaldo(160421059)</p>            
  <table class="table">
    <thead>
      <tr>
        <th>Nama Hotel</th>
        <th>Alamat Hotel</th>
        <th>Kota Hotel</th>
        <th>Created At</th>
        <th>Update At</th>
      </tr>
    </thead>
    <tbody>
        @foreach($data as $d)
      <tr>
        <td>{{$d->name}}</td>
        <td>{{$d->address}}</td>
        <td>{{$d->city}}</td>
        <td>{{$d->created_at}}</td>
        <td>{{$d->update_at}}</td>
      </tr>
      @endforeach
    </tbody>
  </table>
  Kalo mau buat baru <a href="{{ route ('hotels.create') }}">Silahkan Kesini</a>
</div>

</body>
</html> -->