<?php

namespace App\Http\Controllers;

use App\Models\Hotel;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PDOException;

class HotelsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $hotels = DB::table('hotels')->get();
        $hotels = Hotel::all(); //pake Eloquent ORM
        return view('hotel.index', ['data' => $hotels]); //ke folder index.blade.php dan mengirim data dengan key 'data' valuenya hotels
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $type = Type::all();
        return view('hotel.create', ['type' => $type]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = new Hotel();
        $data->name = $request->get('hotel_name');
        $data->address = $request->get('hotel_address');//ambil name dari textfieldnya
        $data->city = $request->get('hotel_city');//ambil name dari textfieldnya
        $data->hotel_type = $request->get('hotel_type');
        $data->image = $request->get('hotel_image');
        $data->save();

        //confirmation
        return redirect()->route('hotels.index')->with('status','Hooray ! your data is successfully recorded!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $type = Type::all();
        $data = Hotel::find($id);
        return view('hotel.edit', ['data' => $data, 'type' => $type]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = Hotel::find($id);
        $data->name = $request->get('hotel_name');
        $data->address = $request->get('hotel_address'); //ambil name dari textfieldnya
        $data->city = $request->get('hotel_city'); //ambil name dari textfieldnya
        $data->hotel_type = $request->get('hotel_type');
        $data->update();
        return redirect()->route('hotels.index')->with('status', 'Yesss! your data is successfully updated!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            $data = Hotel::find($id);
            $data->delete();
            return redirect()->route('hotels.index')->with('status', 'Yesss! your data is successfully Deleted!');
        } catch (PDOException $ex) {
            $msg = "Failed to delete data!, Make sure there is no related data before deleting it!";
            return redirect()->route('hotels.index')->with('status',$msg);
        }
    }
    public function availableHotelRoom()
    {
        $data = Hotel::join('products as p', 'hotels.id', '=', 'p.hotel_id')
            ->select('hotels.id', 'hotels.name', DB::raw('sum(p.available_room)as room'))
            ->groupBy('hotels.id', 'hotels.name')
            ->get();
        // dd($data);
        return view('hotel.availableRoom', compact('data'));
    }
    public function averagePriceHotel()
    {
        $data = Hotel::leftjoin('products as p', 'hotels.id', '=', 'p.hotel_id')
            ->join('types as t', 'hotels.hotel_type', '=', 't.id')
            ->select('t.name as type_name', 'hotels.name', DB::raw('AVG(p.price)as avg_price'))
            ->groupBy('t.name', 'hotels.name')
            ->get();
        // dd($data);
        return view('hotel.avgPriceByHotelType', compact('data'));
    }
    public function showInfo()
    {
        return response()->json(array(
            'status' => 'oke',
            'msg' => "<div class='alert alert-info'>
             Did you know? <br>This message is sent by a Controller.'</div>"
        ), 200);
    }
}
