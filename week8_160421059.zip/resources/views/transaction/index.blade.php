<!-- Extends ini file blade php mau ditempel ke mana -->
@extends('layout.conquer')
@section('content')
<br>

<!-- BUTTON MUNCULKAN MODAL -->
<a class="btn btn-warning" data-toggle="modal" href="#disclaimer">Disclaimer!</a>
<!-- END BUTTON MUNCULKAN MODAL -->

<!-- MODAL -->
<!-- yg penting itu class modal fade dan id(ikutin button) -->
<div class="modal fade" id="disclaimer" tabindex="-1" role="basic" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
        <h4 class="modal-title">DISCLAIMER</h4>
      </div>
      <div class="modal-body">
        Pictures shown are for illustration purpose only. Actual product may vary due to product enhancement.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- END MODAL -->

<div class="container">
  <h2>Daftar Transaksi</h2>
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Pembeli</th>
        <th>Kasir</th>
        <th>Tanggal Transaction</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      @foreach($data as $d)
      <tr>
        <td>{{$d->id}}</td>
        <td>{{$d->customer->name}}</td>
        <td>{{$d->user->name}}</td>
        <td>{{$d->transaction_date}}</td>
        <td>
          <a class="btn btn-default" href="#myModal" data-toggle="modal">Lihat Rincian Pembelian</a>
          <div class="modal fade" id="myModal" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog modal-wide">
              <div class="modal-content" id="msg">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Nama Hotel</th>
                      <th>Nama Produk</th>
                      <th>Subtotal</th>
                      <th>Quantity</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($d->products as $p)
                      <tr>
                        <td>{{$p->hotel->name}}</td>
                        <td>{{$p->name}}</td>
                        <td>{{$p->pivot->subtotal}}</td>
                        <td>{{$p->pivot->quantity}}</td>
                      </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
  Kalo mau buat baru <a href="{{ route ('hotels.create') }}">Silahkan Kesini</a>
</div>
@endsection