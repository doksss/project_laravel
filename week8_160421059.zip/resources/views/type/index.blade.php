@foreach($data as $d)
<p>{{$d->name}}</p>
@endforeach