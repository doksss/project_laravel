<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="card">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_QXb1hJYXjXSH0jwdnUdmxO1C38baIftFVg&usqp=CAU">
        <div class="container">
            <h4>Kamar Single Semi Double</h4>
            <a href="{{route('detailkategori',['namapage'=>'single'])}}">Kamar Single Semi Double</a>
        </div>
    </div>

    <div class="card">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfDneiQB98lvyU8VoR9BcAlnfzj40JdPVNw&usqp=CAU">
        <div class="container">
            <h4>Kamar Standard Double</h4>
            <a href="{{route('detailkategori',['namapage'=>'standard-double'])}}">Kamar Standard Double</a>
        </div>
    </div>

</body>
</html>